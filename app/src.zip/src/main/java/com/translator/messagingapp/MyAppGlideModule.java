package com.translator.messagingapp;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class MyAppGlideModule extends AppGlideModule {
    // You can leave this class empty for now.
    // It's used for custom Glide configuration if needed later.
}

