package com.translator.messagingapp;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Telephony;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Activity for displaying a conversation.
 */
public class ConversationActivity extends BaseActivity implements MessageRecyclerAdapter.OnMessageClickListener {
    private static final String TAG = "ConversationActivity";

    // UI components
    private RecyclerView messagesRecyclerView;
    private MessageRecyclerAdapter adapter;
    private EditText messageInput;
    private Button sendButton;
    private ProgressBar progressBar;
    private TextView emptyStateTextView;
    private ImageButton translateInputButton;
    private ImageButton emojiButton;

    // Data
    private String threadId;
    private String address;
    private String contactName;
    private List<Message> messages;
    private ExecutorService executorService;

    // Service classes
    private MessageService messageService;
    private TranslationManager translationManager;
    private TranslationCache translationCache;
    private UserPreferences userPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conversation_updated);

        // Get service instances from TranslatorApp
        messageService = ((TranslatorApp) getApplication()).getMessageService();
        translationManager = ((TranslatorApp) getApplication()).getTranslationManager();
        translationCache = ((TranslatorApp) getApplication()).getTranslationCache();
        userPreferences = new UserPreferences(this);

        // Get thread ID and address from intent
        threadId = getIntent().getStringExtra("thread_id");
        address = getIntent().getStringExtra("address");
        contactName = getIntent().getStringExtra("contact_name");

        if (TextUtils.isEmpty(threadId) && TextUtils.isEmpty(address)) {
            Log.e(TAG, "No thread ID or address provided");
            finish();
            return;
        }

        // Initialize executor service
        executorService = Executors.newCachedThreadPool();

        // Initialize data
        messages = new ArrayList<>();

        // Initialize UI components
        initializeComponents();

        // Load messages
        loadMessages();
    }

    private void initializeComponents() {
        // Set up toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(contactName != null ? contactName : address);
        }

        // Find views
        messagesRecyclerView = findViewById(R.id.messages_recycler_view);
        messageInput = findViewById(R.id.message_input);
        sendButton = findViewById(R.id.send_button);
        progressBar = findViewById(R.id.progress_bar);
        emptyStateTextView = findViewById(R.id.empty_state_text_view);
        translateInputButton = findViewById(R.id.translate_input_button);
        emojiButton = findViewById(R.id.emoji_button);

        // Set up RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        messagesRecyclerView.setLayoutManager(layoutManager);
        
        // Try to use the updated adapter class if available
        try {
            // Use reflection to check if the updated adapter class exists
            Class<?> updatedAdapterClass = Class.forName("com.translator.messagingapp.MessageRecyclerAdapter_updated");
            if (updatedAdapterClass != null) {
                // Use the updated adapter
                adapter = new MessageRecyclerAdapter(this, messages, this);
            }
        } catch (ClassNotFoundException e) {
            // Use the regular adapter
            adapter = new MessageRecyclerAdapter(this, messages, this);
        }
        
        messagesRecyclerView.setAdapter(adapter);

        // Set up send button
        sendButton.setOnClickListener(v -> sendMessage());

        // Set up translate input button
        translateInputButton.setOnClickListener(v -> translateInput());
        
        // Set up emoji button
        emojiButton.setOnClickListener(v -> showEmojiPicker());

        // Update UI based on theme
        updateUIForTheme();
    }

    private void updateUIForTheme() {
        // Apply theme-specific styling
        boolean isDarkTheme = userPreferences.isDarkThemeEnabled();

        if (isDarkTheme) {
            // Apply dark theme styling
            if (messageInput != null) {
                messageInput.setBackgroundResource(R.drawable.message_input_background_dark);
                messageInput.setTextColor(getResources().getColor(R.color.textColorPrimaryDark));
                messageInput.setHintTextColor(getResources().getColor(R.color.textColorSecondaryDark));
            }

            // Apply additional dark theme styling as needed
        } else {
            // Apply light theme styling
            if (messageInput != null) {
                messageInput.setBackgroundResource(R.drawable.message_input_background_light);
                messageInput.setTextColor(getResources().getColor(R.color.textColorPrimary));
                messageInput.setHintTextColor(getResources().getColor(R.color.textColorSecondary));
            }

            // Apply additional light theme styling as needed
        }
    }

    private void loadMessages() {
        // Show loading indicator
        showLoadingIndicator();

        // Use a background thread to load messages
        executorService.execute(() -> {
            try {
                // Load messages using MessageService
                List<Message> loadedMessages = messageService.loadMessages(threadId);

                // Update UI on main thread
                runOnUiThread(() -> {
                    // Clear existing messages and add loaded ones
                    messages.clear();
                    if (loadedMessages != null) {
                        messages.addAll(loadedMessages);
                    }

                    // Update UI
                    adapter.notifyDataSetChanged();
                    hideLoadingIndicator();

                    // Scroll to bottom
                    if (!messages.isEmpty()) {
                        messagesRecyclerView.scrollToPosition(messages.size() - 1);
                    }

                    // Show empty state if no messages
                    if (messages.isEmpty()) {
                        emptyStateTextView.setText(R.string.no_messages);
                        emptyStateTextView.setVisibility(View.VISIBLE);
                    } else {
                        emptyStateTextView.setVisibility(View.GONE);
                    }

                    // Mark thread as read
                    markThreadAsRead();
                });
            } catch (Exception e) {
                Log.e(TAG, "Error loading messages", e);
                runOnUiThread(() -> {
                    Toast.makeText(ConversationActivity.this,
                            getString(R.string.error_loading_messages) + ": " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    hideLoadingIndicator();
                    emptyStateTextView.setText(R.string.error_loading_messages);
                    emptyStateTextView.setVisibility(View.VISIBLE);
                });
            }
        });
    }

    private void markThreadAsRead() {
        executorService.execute(() -> {
            try {
                messageService.markThreadAsRead(threadId);
            } catch (Exception e) {
                Log.e(TAG, "Error marking thread as read", e);
            }
        });
    }

    private void sendMessage() {
        String messageText = messageInput.getText().toString().trim();
        if (messageText.isEmpty()) {
            return;
        }

        // Clear input
        messageInput.setText("");

        // Show progress
        showLoadingIndicator();

        // Send message in background
        executorService.execute(() -> {
            try {
                boolean success = messageService.sendSmsMessage(address, messageText);

                runOnUiThread(() -> {
                    hideLoadingIndicator();

                    if (success) {
                        // Refresh messages
                        loadMessages();
                    } else {
                        Toast.makeText(ConversationActivity.this,
                                R.string.error_sending_message,
                                Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Error sending message", e);
                runOnUiThread(() -> {
                    hideLoadingIndicator();
                    Toast.makeText(ConversationActivity.this,
                            getString(R.string.error_sending_message) + ": " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void showLoadingIndicator() {
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideLoadingIndicator() {
        progressBar.setVisibility(View.GONE);
    }

    private void showProgressDialog(String message) {
        // Show a progress dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_progress, null);
        TextView messageTextView = dialogView.findViewById(R.id.progress_message);
        messageTextView.setText(message);
        builder.setView(dialogView);
        builder.setCancelable(false);
        AlertDialog dialog = builder.create();
        dialog.show();

        // Store the dialog in a tag
        messageInput.setTag(dialog);
    }

    private void hideProgressDialog() {
        // Hide the progress dialog
        if (messageInput.getTag() instanceof AlertDialog) {
            AlertDialog dialog = (AlertDialog) messageInput.getTag();
            dialog.dismiss();
            messageInput.setTag(null);
        }
    }

    private void translateInput() {
        String inputText = messageInput.getText().toString().trim();
        if (inputText.isEmpty()) {
            Toast.makeText(this, "Please enter text to translate", Toast.LENGTH_SHORT).show();
            return;
        }

        // Show translation in progress
        showProgressDialog("Translating...");

        // Get target language
        String targetLanguage = userPreferences.getPreferredLanguage();

        // Translate in background
        executorService.execute(() -> {
            translationManager.translateText(inputText, targetLanguage, (success, translatedText, errorMessage) -> {
                runOnUiThread(() -> {
                    hideProgressDialog();

                    if (success && translatedText != null) {
                        // Replace input text with translated text
                        messageInput.setText(translatedText);
                        messageInput.setSelection(translatedText.length());
                    } else {
                        Toast.makeText(ConversationActivity.this,
                                getString(R.string.translation_error) + ": " +
                                        (errorMessage != null ? errorMessage : getString(R.string.unknown_error)),
                                Toast.LENGTH_LONG).show();
                    }
                });
            });
        });
    }

    private void translateMessage(Message message, int position) {
        if (message == null || message.getBody() == null) {
            return;
        }

        // Skip if already translated
        if (message.isTranslated() && message.getTranslatedText() != null) {
            message.setShowTranslation(true);
            adapter.notifyItemChanged(position);
            return;
        }

        // Get target language
        String targetLanguage = userPreferences.getPreferredLanguage();

        // Show translation in progress
        showLoadingIndicator();

        // Translate in background
        executorService.execute(() -> {
            translationManager.translateText(message.getBody(), targetLanguage, (success, translatedText, errorMessage) -> {
                runOnUiThread(() -> {
                    hideLoadingIndicator();

                    if (success && translatedText != null) {
                        // Update message with translated text
                        message.setTranslatedText(translatedText);
                        message.setTranslated(true);
                        message.setShowTranslation(true);

                        // Save to cache
                        if (translationCache != null) {
                            translationCache.saveTranslation(message.getId(), translatedText);
                        }

                        // Update UI
                        adapter.notifyItemChanged(position);
                    } else {
                        Toast.makeText(ConversationActivity.this,
                                getString(R.string.translation_error) + ": " +
                                        (errorMessage != null ? errorMessage : getString(R.string.unknown_error)),
                                Toast.LENGTH_LONG).show();
                    }
                });
            });
        });
    }

    private void toggleMessageTranslation(Message message, int position) {
        if (message.isTranslated()) {
            // Toggle between original and translated text
            message.setShowTranslation(!message.isShowTranslation());
            adapter.notifyItemChanged(position);
        } else {
            // Translate the message
            translateMessage(message, position);
        }
    }

    /**
     * Shows the emoji picker dialog for inserting emojis into the message input.
     */
    private void showEmojiPicker() {
        EmojiPickerDialog.show(this, emoji -> {
            // Insert the selected emoji at the current cursor position
            EmojiUtils.insertEmoji(messageInput, emoji);
        }, false); // false indicates this is for emoji input, not reactions
    }
    
    /**
     * Shows the reaction picker dialog for a message.
     * 
     * @param message The message to react to
     * @param position The position of the message in the list
     */
    private void showReactionPicker(Message message, int position) {
        EmojiPickerDialog.show(this, emoji -> {
            // Add the reaction to the message
            String userId = "self"; // In a real app, this would be the user's ID
            boolean added = message.addReaction(emoji, userId);
            
            if (added) {
                // Update the UI
                adapter.notifyItemChanged(position);
                Toast.makeText(this, R.string.reaction_added, Toast.LENGTH_SHORT).show();
            } else {
                // User already reacted with this emoji
                Toast.makeText(this, R.string.reaction_removed, Toast.LENGTH_SHORT).show();
                
                // Remove the reaction
                message.removeReaction(emoji, userId);
                adapter.notifyItemChanged(position);
            }
        }, true); // true indicates this is for reactions
    }

    private void showDeleteMessageConfirmationDialog(Message message, int position) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_message_title)
                .setMessage(R.string.delete_message_confirmation)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    deleteMessage(message, position);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void deleteMessage(Message message, int position) {
        // This is a simplified implementation
        // In a real app, you would delete the message from the content provider
        showLoadingIndicator();

        executorService.execute(() -> {
            try {
                // Simulate deletion
                Thread.sleep(500);

                runOnUiThread(() -> {
                    hideLoadingIndicator();

                    // Remove from list and update UI
                    messages.remove(position);
                    adapter.notifyDataSetChanged();

                    Toast.makeText(ConversationActivity.this, R.string.message_deleted, Toast.LENGTH_SHORT).show();

                    // Show empty state if no messages left
                    if (messages.isEmpty()) {
                        emptyStateTextView.setText(R.string.no_messages);
                        emptyStateTextView.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Error deleting message", e);
                runOnUiThread(() -> {
                    hideLoadingIndicator();
                    Toast.makeText(ConversationActivity.this,
                            getString(R.string.error_deleting_message) + ": " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void copyMessageToClipboard(Message message) {
        try {
            String textToCopy = message.isShowTranslation() && message.isTranslated() ?
                    message.getTranslatedText() : message.getBody();

            ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            ClipData clip =
                    ClipData.newPlainText("Message", textToCopy);

            if (clipboard != null) {
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error copying to clipboard", e);
            Toast.makeText(this, R.string.error_copying_to_clipboard, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.conversation_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onMessageClick(Message message, int position) {
        // Do nothing on click
    }

    @Override
    public void onMessageLongClick(Message message, int position) {
        // Show message options
        showMessageOptionsDialog(message, position);
    }

    @Override
    public void onTranslateClick(Message message, int position) {
        // Translate the message
        translateMessage(message, position);
    }

    @Override
    public void onAttachmentClick(MmsMessage.Attachment attachment, int position) {
        // Handle attachment click
        // You'll need to implement this method to handle attachment clicks
        Toast.makeText(this, "Attachment clicked", Toast.LENGTH_SHORT).show();
    }
    
    @Override
    public void onReactionClick(Message message, int position) {
        // Show reaction details or toggle user's reaction
        showReactionPicker(message, position);
    }
    
    @Override
    public void onAddReactionClick(Message message, int position) {
        // Show reaction picker
        showReactionPicker(message, position);
    }

    private void showMessageOptionsDialog(Message message, int position) {
        String[] options;

        if (message.isTranslated()) {
            options = new String[]{"Add Reaction", "Copy message", "Show original", "Translate again", "Delete message"};
        } else {
            options = new String[]{"Add Reaction", "Copy message", "Translate", "Delete message"};
        }

        new AlertDialog.Builder(this)
                .setTitle("Message Options")
                .setItems(options, (dialog, which) -> {
                    if (options[which].equals("Add Reaction")) {
                        showReactionPicker(message, position);
                    } else if (options[which].equals("Copy message")) {
                        copyMessageToClipboard(message);
                    } else if (options[which].equals("Show original") || options[which].equals("Translate")) {
                        toggleMessageTranslation(message, position);
                    } else if (options[which].equals("Translate again")) {
                        translateMessage(message, position);
                    } else if (options[which].equals("Delete message")) {
                        showDeleteMessageConfirmationDialog(message, position);
                    }
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Clean up resources
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }
}